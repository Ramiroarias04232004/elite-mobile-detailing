// Home page: mobile navigation and animated canvas car.
"use strict";

const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".main-nav");

menuButton.addEventListener("click", () => {
  const isOpen = navigation.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", isOpen);
});

const canvas = document.getElementById("shineCanvas");
const ctx = canvas.getContext("2d");
let width = 0;
let height = 0;
let animationFrame;

function resizeCanvas() {
  const ratio = window.devicePixelRatio || 1;
  const bounds = canvas.getBoundingClientRect();
  width = bounds.width;
  height = bounds.height;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
}

function drawCar(time) {
  ctx.clearRect(0, 0, width, height);
  const centerY = height * 0.58;
  const carWidth = Math.min(width * 0.66, 440);
  const carHeight = carWidth * 0.25;
  const left = (width - carWidth) / 2;

  // Ground shadow
  ctx.fillStyle = "rgba(0,0,0,.42)";
  ctx.beginPath();
  ctx.ellipse(width / 2, centerY + carHeight * .65, carWidth * .55, 17, 0, 0, Math.PI * 2);
  ctx.fill();

  // Car body
  const bodyGradient = ctx.createLinearGradient(0, centerY - 40, 0, centerY + carHeight);
  bodyGradient.addColorStop(0, "#e6b95c");
  bodyGradient.addColorStop(.45, "#b83e38");
  bodyGradient.addColorStop(1, "#501d24");
  ctx.fillStyle = bodyGradient;
  ctx.beginPath();
  ctx.moveTo(left + carWidth * .08, centerY);
  ctx.lineTo(left + carWidth * .22, centerY - carHeight * .35);
  ctx.quadraticCurveTo(left + carWidth * .32, centerY - carHeight * 1.1, left + carWidth * .49, centerY - carHeight * 1.05);
  ctx.lineTo(left + carWidth * .72, centerY - carHeight * .95);
  ctx.quadraticCurveTo(left + carWidth * .82, centerY - carHeight * .7, left + carWidth * .91, centerY - carHeight * .2);
  ctx.lineTo(left + carWidth * .98, centerY);
  ctx.quadraticCurveTo(left + carWidth, centerY + carHeight * .25, left + carWidth * .91, centerY + carHeight * .35);
  ctx.lineTo(left + carWidth * .08, centerY + carHeight * .35);
  ctx.quadraticCurveTo(left, centerY + carHeight * .25, left + carWidth * .08, centerY);
  ctx.fill();

  // Windows
  ctx.fillStyle = "#172431";
  ctx.beginPath();
  ctx.moveTo(left + carWidth * .28, centerY - carHeight * .38);
  ctx.quadraticCurveTo(left + carWidth * .36, centerY - carHeight * .88, left + carWidth * .49, centerY - carHeight * .86);
  ctx.lineTo(left + carWidth * .57, centerY - carHeight * .82);
  ctx.lineTo(left + carWidth * .57, centerY - carHeight * .35);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(left + carWidth * .6, centerY - carHeight * .81);
  ctx.lineTo(left + carWidth * .7, centerY - carHeight * .75);
  ctx.quadraticCurveTo(left + carWidth * .77, centerY - carHeight * .57, left + carWidth * .81, centerY - carHeight * .35);
  ctx.lineTo(left + carWidth * .6, centerY - carHeight * .35);
  ctx.closePath();
  ctx.fill();

  // Wheels
  [left + carWidth * .25, left + carWidth * .77].forEach((wheelX) => {
    ctx.fillStyle = "#080a0d";
    ctx.beginPath();
    ctx.arc(wheelX, centerY + carHeight * .31, carHeight * .38, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#c7cbd1";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(wheelX, centerY + carHeight * .31, carHeight * .22, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "#e6b95c";
    ctx.beginPath();
    ctx.arc(wheelX, centerY + carHeight * .31, 4, 0, Math.PI * 2);
    ctx.fill();
  });

  // Moving shine sweep
  const sweepX = ((time * .12) % (width + 180)) - 90;
  const shine = ctx.createLinearGradient(sweepX - 65, 0, sweepX + 65, 0);
  shine.addColorStop(0, "rgba(255,255,255,0)");
  shine.addColorStop(.5, "rgba(255,255,255,.42)");
  shine.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = shine;
  ctx.fillRect(0, centerY - carHeight, width, carHeight * 1.5);

  ctx.fillStyle = "rgba(230,185,92,.8)";
  ctx.font = "600 11px Arial";
  ctx.textAlign = "center";
  ctx.fillText("ELITE FINISH", width / 2, height - 22);
  animationFrame = requestAnimationFrame(drawCar);
}

resizeCanvas();
if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  animationFrame = requestAnimationFrame(drawCar);
} else {
  drawCar(0);
  cancelAnimationFrame(animationFrame);
}
window.addEventListener("resize", resizeCanvas);
