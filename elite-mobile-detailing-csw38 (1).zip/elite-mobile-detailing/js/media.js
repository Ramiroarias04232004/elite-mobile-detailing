// Media page: mobile navigation and animated detailing wheel.
"use strict";

const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".main-nav");

menuButton.addEventListener("click", () => {
  const isOpen = navigation.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", isOpen);
});

const canvas = document.getElementById("detailCanvas");
const ctx = canvas.getContext("2d");
let width = 0;
let height = 0;
let angle = 0;
let bubbles = [];

function resizeCanvas() {
  const ratio = window.devicePixelRatio || 1;
  const bounds = canvas.getBoundingClientRect();
  width = bounds.width;
  height = bounds.height;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  bubbles = Array.from({length: 18}, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    radius: 2 + Math.random() * 8,
    speed: .3 + Math.random() * .8
  }));
}

function drawWheel() {
  ctx.clearRect(0, 0, width, height);
  const cx = width / 2;
  const cy = height / 2 - 2;
  const radius = Math.min(105, height * .31, width * .18);

  bubbles.forEach((bubble) => {
    bubble.y -= bubble.speed;
    if (bubble.y < -10) {
      bubble.y = height + 10;
      bubble.x = Math.random() * width;
    }
    ctx.beginPath();
    ctx.arc(bubble.x, bubble.y, bubble.radius, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(230,185,92,.35)";
    ctx.stroke();
  });

  // Tire
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(angle);
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fillStyle = "#080a0d";
  ctx.fill();
  ctx.strokeStyle = "#555e69";
  ctx.lineWidth = 8;
  ctx.stroke();

  // Spokes
  for (let i = 0; i < 10; i += 1) {
    ctx.rotate(Math.PI / 5);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, radius * .82);
    ctx.strokeStyle = "#d6dbe1";
    ctx.lineWidth = 5;
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(0, 0, radius * .27, 0, Math.PI * 2);
  ctx.fillStyle = "#e6b95c";
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = "#f4f5f7";
  ctx.font = "600 12px Arial";
  ctx.textAlign = "center";
  ctx.fillText("ROTATING DETAIL • CLEAN WHEELS", cx, height - 18);

  angle += .012;
  requestAnimationFrame(drawWheel);
}

resizeCanvas();
if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  ctx.fillStyle = "#e6b95c";
  ctx.font = "600 14px Arial";
  ctx.textAlign = "center";
  ctx.fillText("ELITE WHEEL DETAIL", width / 2, height / 2);
} else {
  drawWheel();
}
window.addEventListener("resize", resizeCanvas);
