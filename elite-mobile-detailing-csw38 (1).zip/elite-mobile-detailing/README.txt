ELITE MOBILE DETAILING — CSW 38 WEB ANIMATION PROJECT

PROJECT FILES
- index.html: Home page
- about.html: About page
- media.html: Media page
- css/: one external stylesheet for each page
- js/: one external JavaScript file for each page

HOW TO TEST
1. Extract the ZIP file.
2. Open the elite-mobile-detailing folder.
3. Double-click index.html to open the home page in a browser.
4. Use the Home / About / Media navigation links to test all three pages.
5. Resize the browser to check desktop, tablet, and mobile layouts.
6. On the Media page, test the embedded YouTube video. Internet access is required.

BEFORE SUBMITTING
1. In about.html, replace [Your Name] with your name.
2. Check the creation date and copyright details.
3. Prices are sample student-project prices. Edit them if needed.
4. The images are loaded from Unsplash and the video is embedded from YouTube, so those items require internet access.
5. Check that all three pages and animations work after publishing.

PUBLISH WITH GITHUB PAGES
1. Sign in at https://github.com/ and create a new public repository.
2. Upload the contents of this folder (the three HTML files and the css and js folders).
3. Open the repository's Settings, then Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and the root folder, then Save.
6. Wait for GitHub Pages to publish. Your home page URL will look like:
   https://YOUR-USERNAME.github.io/REPOSITORY-NAME/
7. Open the live URL and test Home, About, Media, animations, and video.
8. Submit the live home page URL to your instructor.

NOTES
- This is a student project template, not a claim of an operating business.
- All JavaScript is in linked .js files.
- Each page has its own linked CSS file and JavaScript file.
- Canvas graphics are generated in JavaScript.
