// About page: mobile navigation and animated canvas bubbles.
"use strict";

const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".main-nav");

menuButton.addEventListener("click", () => {
  const isOpen = navigation.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", isOpen);
});

const canvas = document.getElementById("bubbleCanvas");
const ctx = canvas.getContext("2d");
let width = 0;
let height = 0;
let bubbles = [];

function resizeCanvas() {
  const ratio = window.devicePixelRatio || 1;
  const bounds = canvas.getBoundingClientRect();
  width = bounds.width;
  height = bounds.height;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  bubbles = Array.from({length: 24}, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    radius: 3 + Math.random() * 13,
    speed: .25 + Math.random() * .8,
    drift: (Math.random() - .5) * .5
  }));
}

function animateBubbles() {
  ctx.clearRect(0, 0, width, height);
  bubbles.forEach((bubble, index) => {
    bubble.y -= bubble.speed;
    bubble.x += Math.sin(Date.now() / 900 + index) * bubble.drift;
    if (bubble.y < -bubble.radius * 2) {
      bubble.y = height + bubble.radius;
      bubble.x = Math.random() * width;
    }
    ctx.beginPath();
    ctx.arc(bubble.x, bubble.y, bubble.radius, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(230,185,92,.62)";
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(bubble.x - bubble.radius * .3, bubble.y - bubble.radius * .3, Math.max(1, bubble.radius * .16), 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,.65)";
    ctx.fill();
  });
  ctx.fillStyle = "rgba(230,185,92,.9)";
  ctx.font = "600 12px Arial";
  ctx.textAlign = "center";
  ctx.fillText("CLEAN • PROTECT • SHINE", width / 2, height - 20);
  requestAnimationFrame(animateBubbles);
}

resizeCanvas();
if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  bubbles = bubbles.slice(0, 0);
  ctx.fillStyle = "#e6b95c";
  ctx.font = "600 14px Arial";
  ctx.textAlign = "center";
  ctx.fillText("CLEAN • PROTECT • SHINE", width / 2, height / 2);
} else {
  animateBubbles();
}
window.addEventListener("resize", resizeCanvas);
